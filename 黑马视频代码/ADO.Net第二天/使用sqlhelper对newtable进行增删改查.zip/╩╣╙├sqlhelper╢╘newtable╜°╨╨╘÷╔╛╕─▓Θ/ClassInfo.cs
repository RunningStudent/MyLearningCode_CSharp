﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 使用sqlhelper对newtable进行增删改查
{
    class ClassInfo
    {
        public int classId { get; set; }
        public string className { get; set; }
        public string classDesc { get; set; }
    }
}
